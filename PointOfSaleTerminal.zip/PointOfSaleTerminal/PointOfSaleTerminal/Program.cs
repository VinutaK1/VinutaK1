﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;

namespace PointOfSaleTerminal
{
    class Program
    {
        public static void Main(string[] args)
        {
            //User to enter the details for shopping
           saleTerminal();           

        }

        private static void saleTerminal()
        {
            Console.WriteLine("\r\n Product A = $1.25 each or 3 for $3.00 \r\n Product B = $4.25 \r\n Product C = $1.00 or $5 for a six pack " +
               "\r\n Product D = $0.75");

            Console.WriteLine("Please enter the products in the form eg:A/B/C ..  : ");
            var selectedProduct = Console.ReadLine();

            Console.WriteLine("Please enter the quantity of the choosen product : ");
            var selectedProdQuantity = Console.ReadLine();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53059/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));

                prodPriceCalculation(selectedProduct, client, Convert.ToInt32(selectedProdQuantity)).Wait();
            }
        }

        static async Task prodPriceCalculation(string selectedProduct, HttpClient httpClient, int selectedProdQuantity)
        {
            double baseValue;
            HttpResponseMessage res;
            HttpStatusCode statuscode;
            using (httpClient)
            {
                string uri = string.Format("{0}/{1}/{2}", "api/Product/", selectedProduct, selectedProdQuantity);
                res = await httpClient.GetAsync(uri);
                if (res.IsSuccessStatusCode)
                {
                    baseValue = await res.Content.ReadAsAsync<double>();
                    Console.WriteLine($"Price : {baseValue}");

                    Console.WriteLine("Do you want to exit the shopping yes/no :");
                    var endOfShopping = Console.ReadLine();

                    if (endOfShopping == "yes")
                    {
                        Environment.Exit(0);
                    }
                    else
                        saleTerminal();

                }
                else
                {
                    statuscode = res.StatusCode;
                    Console.WriteLine($"Product {statuscode}");

                    Console.WriteLine("Do you want to exit the shopping yes/no :");
                    var endOfShopping = Console.ReadLine();

                    if (endOfShopping == "yes")
                    {
                        Environment.Exit(0);
                    }
                    else
                        saleTerminal();
                }
            }
        }
    }
}
